import pymysql


def obtener_conexion():
    return pymysql.connect(host='dannkol.mysql.pythonanywhere-services.com',
                                user='dannkol',
                                password='campus123',
                                db='dannkol$asistente2')